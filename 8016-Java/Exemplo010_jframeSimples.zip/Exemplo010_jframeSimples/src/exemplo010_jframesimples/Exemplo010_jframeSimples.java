/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemplo010_jframesimples;

/**
 *
 * @author Gabriela
 */
public class Exemplo010_jframeSimples {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        JFrame_Form f1=new JFrame_Form();
        f1.setVisible(true);
        f1.setLocation(200, 200);        
        
    }
    
}
