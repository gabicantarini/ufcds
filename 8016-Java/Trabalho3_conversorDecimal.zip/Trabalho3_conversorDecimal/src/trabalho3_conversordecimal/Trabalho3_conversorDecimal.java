/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabalho3_conversordecimal;

/**
 *
 * @author Gabriela
 */
public class Trabalho3_conversorDecimal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Classe_Janela f1;
        f1=new Classe_Janela();
        f1.setVisible(true);
    }
    
}
